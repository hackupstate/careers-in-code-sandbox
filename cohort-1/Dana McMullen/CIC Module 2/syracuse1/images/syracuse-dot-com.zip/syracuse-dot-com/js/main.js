document.addEventListener('click', function() {
    //show search bar
    console.log("show search bar");
    document.querySelector('.search-bar').style.display = "block";
})

console.log('file loaded');
// document.querySelector('.search-bar').style.display = "block";