import React, { Component } from "react";

export default class HelloWorld extends Component {
    render() {
        return (
            <div className="container">
                <h1>HelloWorld</h1>
            </div>
        );
    }
}