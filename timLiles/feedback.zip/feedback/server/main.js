import { Meteor } from "meteor/meteor";
import Feedback from "../imports/api/feedback.js";

Meteor.startup(() => {});
